/**Used to store cards & scores/players & Basic Functions**/

var jobs = ['Looks good in yoga class','Showoff to my neighbor','Gives a pleasant aroma','Win a cosplay competition'];
var jobs_used = [];
var quals = [['Linen','Cashmere','Cotton','Wool','Ramie','Silk','Denim','Leather','Down','Fur','Nylon','Polyesters','Spandex','Acetate','Cupro','Flannel','Lyocell','Polyvinyl Chloride','Rayon','Cotton','Recycled PET','Recycled Bob','Tyvek','Vinylon','Bamboo','Jute','Hemp','Alpaca','Mohair','Angora','Catgut','Sinew','Horse Hair','Bone','Gold','Aluminum','Chocolate','Human Hair','Electroluminescent Paper','Wood Pulp / Naoron','PVC Pipe','Recycled Newspaper Yarn','Recycled Plastic Bottles (Newlife Polyester)','Ingeo (Corn Fiber)','Spider Silk','Hagfish Slime','Dollar Bills'],['Linen','Cashmere','Cotton','Wool','Ramie','Silk','Denim','Leather','Down','Fur','Nylon','Polyesters','Spandex','Acetate','Cupro','Flannel','Lyocell','Polyvinyl Chloride','Rayon','Cotton','Recycled PET','Recycled Bob','Tyvek','Vinylon','Bamboo','Jute','Hemp','Alpaca','Mohair','Angora','Catgut','Sinew','Horse Hair','Bone','Gold','Aluminum','Chocolate','Human Hair','Electroluminescent Paper','Wood Pulp / Naoron','PVC Pipe','Recycled Newspaper Yarn','Recycled Plastic Bottles (Newlife Polyester)','Ingeo (Corn Fiber)','Spider Silk','Hagfish Slime','Dollar Bills'],['Tiara','Skirt','Dress','Sweater','Jacket','Coat','Jeans','Socks','Shorts','Tracksuit','Chainmail Armor','Vest','Pajamas','Shoes','Boots','Raincoat','Tanktop','Swimsuit','Heels','Blouse','Bra','Panties','Stockings','Suit','Shirt','TIe','Bow-Tie','Bracelet','Briefs','Earrings','Necklace','Sun Hat','Wool Hat','Scarf','Glasses','Sunglasses','Bagpack','Bag','Earrings','Bracelet','Belt','Handkerchief','Necklace','Purse','Wallet','Hat','Cap'],['Gothic','Parisian','1910s','1920s','1930s','1940s','1950s','1960s','Emo','1970s','1980s','1990s','2000s','2010s','2020s','Artsy','Casual','Grunge','Chic','Medieval','Space Traveler','Bohemian','Sexy','Exotic','Trendy','Vibrant','Preppy','Elegant','Cowgirl','Girl Next Door','Punk','Tomboy','Rocker','Sporty','Japanese','Afghan','Mexican','Ethnic','Formal Office','Evening','Girly','Maternity','Lolita','Hip Hop','Kawaii','Lagenlook','Geeky Chic']];
var quals_used = [[],[],[],[]];

//counters
var scores = {}; //example, will populate with function later
var numPlayers = 0;
var currentBoss = 0;
var currentPlayer = 1; //tracks which player/employee is going up for quals
var qualCounter = 1;

//Helper Functions
function getJob(){
	if(jobs.length === 0){
		jobs = jobs.concat(jobs_used);
		jobs_used = [];
	}
	var index = Math.floor(Math.random() * jobs.length); //random var
	var result = jobs[index]; //returns result later
	jobs_used = jobs_used.concat(jobs.splice(index, 1)); //puts the jobs into used arr
	return result; //returns result
}
function getQual(qualClass){
	if(quals[qualClass].length === 0){
		quals[qualClass] = quals[qualClass].concat(quals_used[qualClass]);
		quals_used[qualClass] = [];
	}
	var index = Math.floor(Math.random() * quals[qualClass].length); //random var
	var result = quals[qualClass][index]; //returns result later
	quals_used[qualClass] = quals_used[qualClass].concat(quals[qualClass].splice(index, 1)); //puts the quals into used arr
	return result; //returns result
}
function nextBoss(){
	return (currentBoss+1 == numPlayers)?0:currentBoss+1; // basically cycles through the players properly
}
function pName(x){
	return Object.keys(scores)[x]; //return dictionary entry using index
}


/***********Animations*************/
//Animate Functions
function animateTitle(){
	$("#MainPage .select").hide();
	$('#MainPage .boxes').hide();
	$('#MainPage .startgame').hide();
	$('#MainPage .howPlay').hide();
	for(i=0;i<3;i++){
		var nSelector = "input[name='pName" + i + "']";
		$(nSelector).hide();
	}
	quickAnim("#MainPage .title", "zoomIn");
	setTimeout(quickAnim, 400, '#MainPage .select', 'zoomIn',);
	setTimeout(quickAnim, 800, '#MainPage .boxes', 'zoomIn',);
	for(i=0;i<3;i++){
		var nSelector = "input[name='pName" + i + "']";
		setTimeout(quickAnim, 750+(75*i), nSelector, 'zoomIn',);
	}
	setTimeout(quickAnim, 1200, '#MainPage .startgame', 'zoomIn');
	setTimeout(quickAnim, 1250, '#MainPage .howPlay', 'zoomIn');
}
function roundStartAnim(){
	setTimeout(quickAnim, 1100, "#GamePage", "slideInDown");
	
	$("#GamePage").children().hide();
	$("#GamePage h1").show();
	var timeoutCounter = 2100;
	var timeoutInterval = 500;
	$("#GamePage").children().each(function () {
	  	if(!$(this).is("h1") && !$(this).is("div#pickWinner")){
	  		setTimeout(quickAnimObj, timeoutCounter, $(this), "slideInRight");
	  		timeoutCounter+=timeoutInterval;
	  	}
	});
	
}

//Animate Helper Functions
function quickAnim(selector, animName){
  $(selector).addClass(animName + ' animated').show().one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
    $(this).removeClass(animName + ' animated');
    $(this).show();
  });
};
function quickAnimObj(Obj, animName){
  Obj.addClass(animName + ' animated').show().one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
    Obj.removeClass(animName + ' animated');
    Obj.show();
  });
};

function quickAnimHide(selector, animName){
  $(selector).addClass(animName + ' animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
  	$(this).hide();
    $(this).removeClass(animName + ' animated');
  });
};

animateTitle();

